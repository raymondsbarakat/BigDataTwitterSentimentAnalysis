#! /Library/Frameworks/Python.framework/Versions/3.7/bin/pip3
import datetime
import pandas as pd
import twint

c = twint.Config()



partyKeywords =['Liberal OR Liberals OR trudeau',
                   'conservative OR conservatives OR Scheer',
                   '\"NDP OR Jagmeet Singh\"']


provinces = ['British Columbia', 'New Brunswick', 'Newfoundland and Labrador',
             'Nova Scotia', 'Ontario', 'Prince Edward Island', 'Quebec', 'Saskatchewan']
for province in provinces:
    for party in partyKeywords:
        c.Search = party
        c.Since = "2015-10-21 00:00:00"
        c.Until = "2019-10-21 00:00:00"
        c.Near = province
        c.Geo = "43.634380,-79.789842,1000km"
        tweets = []
        c.Store_object = True
        c.Store_object_tweets_list = tweets

        # c.Since = str(datetime.datetime.strptime("2019-07-21 00:00:00", "%Y-%m-%d %H:%M:%S").timestamp()).split('.')[0]
        # c.Until = str(datetime.datetime.strptime("2019-07-21 00:00:00", "%Y-%m-%d %H:%M:%S").timestamp()).split('.')[0]
        c.Store_csv = True
        c.Output = "politicalTweetsRiding"+party+".csv"
        twint.run.Search(c)
